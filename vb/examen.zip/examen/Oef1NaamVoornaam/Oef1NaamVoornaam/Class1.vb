﻿Public Class Class1
    'Vak, Toetsdatum, Leerlingnummer, cijfer, max

End Class
