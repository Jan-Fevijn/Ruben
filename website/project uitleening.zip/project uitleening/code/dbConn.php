<?php 
$servername = "localhost";
$username = "root";
$password = "usbw";
$dbname = "games";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>