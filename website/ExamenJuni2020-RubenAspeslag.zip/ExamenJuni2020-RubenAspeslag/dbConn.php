<?php 
$servername = "localhost";
$username = "root";
$password = "usbw";
$dbname = "examenwdjuni2020";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>