<?php
\Paynl\Config::setApiToken('bf81d83f6f8ca32bca272dfdcaf2f14902ff41');
\Paynl\Config::setServiceId('SL-3490-4320');
\Paynl\Config::setTokenCode('AT-0123-4567');

//optional: you can download it on https://curl.haxx.se/ca/cacert.pem
//\Paynl\Config::setCAInfoLocation('path/to/cacert.pem');
// Or you can skip verifyPeer
//\Paynl\Config::setVerifyPeer(false);
