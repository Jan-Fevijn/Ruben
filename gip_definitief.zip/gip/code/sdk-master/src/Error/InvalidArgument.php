<?php

namespace Paynl\Error;


class InvalidArgument extends Error
{

}