<?php

namespace Paynl\Error;

/**
 * Api error
 *
 * @author Andy Pieters <andy@pay.nl>
 */
class Api extends Error
{
    //put your code here
}
