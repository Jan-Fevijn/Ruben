<?php

namespace Paynl\Error;

/**
 * Description of Error
 *
 * @author Andy Pieters <andy@andypieters.nl>
 */
class Error extends \Exception
{
    //put your code here
}
