<?php

namespace Paynl\Result\Instore;

use Paynl\Result\Result;

/**
 * Result class for instore confirm payment
 *
 * @author Andy Pieters <andy@pay.nl>
 */
class ConfirmPayment extends Result
{
}
