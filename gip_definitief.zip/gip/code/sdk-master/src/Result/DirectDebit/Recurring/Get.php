<?php

namespace Paynl\Result\DirectDebit\Recurring;

use Paynl\Result\Result;

class Get extends Result
{
    /**
     * todo: functies maken om data op te halen
     */
}
