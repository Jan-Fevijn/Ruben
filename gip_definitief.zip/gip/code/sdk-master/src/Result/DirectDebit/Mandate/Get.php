<?php

namespace Paynl\Result\DirectDebit\Mandate;

use Paynl\Result\Result;

class Get extends Result
{
    /**
     * todo: functies maken om data op te halen
     */
}
