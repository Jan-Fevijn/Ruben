<?php

namespace Paynl\Api\Instore;

use Paynl\Api\Api;

/**
 * Description of Instore
 *
 * @author Andy Pieters <andy@pay.nl>
 */
class Instore extends Api
{
    /**
     * @inheritdoc
     */
    protected $version = 2;
}
