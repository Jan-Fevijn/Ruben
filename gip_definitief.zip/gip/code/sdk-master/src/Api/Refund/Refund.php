<?php

namespace Paynl\Api\Refund;

use Paynl\Api\Api;

/**
 * Description of Instore
 *
 * @author Chris de Jong <chris@eventix.io>
 */
class Refund extends Api
{
    /**
     * @inheritdoc
     */
    protected $version = 2;
}
