<?php

namespace Paynl\Api\Validate;

use Paynl\Api\Api;

/**
 * @author Andy Pieters <andy@pay.nl>
 */
class Validate extends Api
{
    /**
     * @var int the version of the api
     */
    protected $version = 1;
}
