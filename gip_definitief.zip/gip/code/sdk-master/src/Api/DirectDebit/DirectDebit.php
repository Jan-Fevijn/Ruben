<?php

namespace Paynl\Api\DirectDebit;

use Paynl\Api\Api;

/**
 * @author Andy Pieters <andy@pay.nl>
 */
class DirectDebit extends Api
{
    /**
     * @var int the version of the api
     */
    protected $version = 3;
}
