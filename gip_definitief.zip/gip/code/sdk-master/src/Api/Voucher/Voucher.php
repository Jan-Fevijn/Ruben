<?php

namespace Paynl\Api\Voucher;

use Paynl\Api\Api;

class Voucher extends Api
{

    /**
     * @var int the version of the api
     */
    protected $version = 1;
}
