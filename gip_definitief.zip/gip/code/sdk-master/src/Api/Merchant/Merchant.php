<?php

namespace Paynl\Api\Merchant;

use Paynl\Api\Api;

class Merchant extends Api
{
    protected $version = 2;
    protected $apiTokenRequired = true;
}
