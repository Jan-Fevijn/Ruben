﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <link rel="stylesheet"
          type="text/css"
          href="../css/css.css" />
</head>
<body>

  <?php
  include("banner.php");
?>

    <div id="registreerContainer">


        <div id="regestratieVraag1">
            <h2>Hoe wilt u registreren?</h2>
            <div id="midden">
                <a href="leerkrachtRegistratie.php" id="registreerKeuzeKnop">leerkracht</a>
                <a href="leerlingRegistratie.php" id="registreerKeuzeKnop">leerling</a>
            </div>
       
	
            <?php
include("footer.php");
?>
   
</body>
</html>