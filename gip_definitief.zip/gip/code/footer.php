<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<div id="footer">
	  <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                           <h4>Adressen</h4>
						<hr/>
						<h5>school (Jan Fevijn)</h5>
						Daverlostraat 132,<br> 8310 Assebroek <br>
						 <a target="_blank" id="footerLink" href="https://www.janfevijn.be/" class="learnmore">Learn More <i class="fa fa-caret-right"></i></a>
						<br> <br>
						<h5>webdesigner (Ruben Aspeslag)</h5>
                        
                        <p>Elzenstraat 2 ,<br> 8000 Brugge <p>
                        </p>
						
                        <a  id="footerLink" href="aboutUs.php" class="learnmore">Learn More <i class="fa fa-caret-right"></i></a>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                               <li><a id="footerLink"  href="../index.php" >home</a></li><br>
                            <li><a id="footerLink" href="ourService.php">onze service</a></li><br>
                            <li><a id="footerLink" href="aboutUs.php">over ons</a></li><br>
                            <li><a id="footerLink" href="contactUs.php">Contacteer ons</a></li><br>
                            <li><a id="footerLink" href="registreer.php">registreer</a></li><br>
                            <li><a id="footerLink" href="../index.php">inloggen</a></li><br>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>uitvoering</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a target="_blank" id="footerLink" href="planning.php">planning</a></li><br>
                            <li><a target="_blank" id="footerLink" href="logboek.php">logboek</a></li><br>
                            <li><a target="_blank" id="footerLink" href="../documents/gebruiksaanwijzingArduinoEducatief.pdf" download>gebruiksaanwijzing</a></li><br>
                        </ul>
                    </div>
                </div>

                

            </div>
        </div>


    </section>
	  </div>
  
   

        </div>
        <a class="open" href="#"><span><i class="fa fa-gear fa-spin"></i></span></a>
  